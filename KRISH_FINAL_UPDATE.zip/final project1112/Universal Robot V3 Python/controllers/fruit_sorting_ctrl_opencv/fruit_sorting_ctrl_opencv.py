"""fruit_sorting_ctrl_opencv controller."""
import cv2
import numpy as np
from controller import Supervisor
import os

robot = Supervisor()

# Set the time step in 32
timestep = 32

# Type of fruit:  0 = orange, 1 = apple
fruit = -1

# Fruits counters
red_apple= 0
green_apple = 0

# Delay counter
counter = 0

# Status of UR5e Robot
state = 0

# Target positions to drop fruits
target_positions = [-1.570796, -1.87972, -2.139774, -2.363176, -1.50971]

# Speed of UR5e Robot
speed = 2

# Getting and declaring the 3 finger motors of the gripper 
hand_motors = []
hand_motors.append(robot.getDevice('finger_1_joint_1'))
hand_motors.append(robot.getDevice('finger_2_joint_1'))
hand_motors.append(robot.getDevice('finger_middle_joint_1'))

# Getting and declaring the robot motor
ur_motors = []
ur_motors.append(robot.getDevice('shoulder_pan_joint'))
ur_motors.append(robot.getDevice('shoulder_lift_joint'))
ur_motors.append(robot.getDevice('elbow_joint'))
ur_motors.append(robot.getDevice('wrist_1_joint'))
ur_motors.append(robot.getDevice('wrist_2_joint'))

# Seting velocity of UR5e motors
for i in range(5):
    ur_motors[i].setVelocity(speed)

# Getting and declaring distance sensor of gripper
distance_sensor = robot.getDevice('distance sensor')
distance_sensor.enable(timestep)

# Getting and declaring position sensor of wrist robot
position_sensor = robot.getDevice('wrist_1_joint_sensor')
position_sensor.enable(timestep)

# Initialize camera
camera = robot.getDevice('camera')
camera.enable(timestep)

# Initialize display
display = robot.getDevice('display')
display.attachCamera(camera)
display.setColor(0x00FF00)
display.setFont('Verdana', 16, True)





def resetDisplay():
    display.setAlpha(0.0)
    display.fillRectangle(0, 0, 200, 150)
    display.setAlpha(1.0)

def printDisplay(x, y, w, h, name):
    resetDisplay()
    display.drawRectangle(x, y, w, h)
    display.drawText(name, x - 2, y - 20)


controller_path = os.path.dirname(__file__)          # same folder as .py
apple_img  = cv2.imread(os.path.join(controller_path, 'apple.png'))
orange_img    = cv2.imread(os.path.join(controller_path, 'orange.png'))
apple_gray = cv2.cvtColor(apple_img, cv2.COLOR_BGR2GRAY)
orange_gray   = cv2.cvtColor(orange_img,   cv2.COLOR_BGR2GRAY)

def findFruit():
    """Return 0 for apple, 1 for orange, -1 if nothing detected."""
    # grab current camera image
    img = np.frombuffer(camera.getImage(), dtype=np.uint8)
    img = img.reshape((camera.getHeight(), camera.getWidth(), 4))
    img = cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)          #
    roi = img[0:150, 35:165]                             

    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)

    # template matching
    res_apple = cv2.matchTemplate(gray, apple_gray, cv2.TM_CCOEFF_NORMED)
    res_orange   = cv2.matchTemplate(gray, orange_gray,   cv2.TM_CCOEFF_NORMED)

    _, max_apple, _, max_loc_apple = cv2.minMaxLoc(res_apple)
    _, max_orange,   _, max_loc_orange   = cv2.minMaxLoc(res_orange)

    threshold = 0.65
    best_cls  = -1
    best_xywh = None

    if max_apple > max_orange and max_apple > threshold:
        best_cls  = 0
        h, w      = apple_gray.shape
        best_xywh = (*max_loc_apple, w, h)
        

    elif max_orange > threshold:
        best_cls  = 1
        h, w      = orange_gray.shape
        best_xywh = (*max_loc_orange, w, h)
        
    if best_cls != -1:
        # Update robot display with detected fruit
        x, y, w, h = best_xywh
       
    

        
        
    return best_cls

# Main loop:
while robot.step(timestep) != -1:
    # ifs for the different state of the arm
    if counter <= 0:
        if state == 0: # WAITING
            fruit = findFruit()
            if distance_sensor.getValue() < 500:
                state = 1 # PICKING
                
                if fruit == 0:
                    green_apple += 1
                elif fruit == 1:
                    red_apple += 1
                counter = 8
                for i in range(3):
                    hand_motors[i].setPosition(0.52)

        elif state == 1: # PICKING
            for i in range(fruit, 5):
                ur_motors[i].setPosition(target_positions[i])
            state = 2 # ROTATING

        elif state == 2: # ROTATING
            if position_sensor.getValue() < -2.3:
                counter = 8
                state = 3 # DROPPING
                resetDisplay()
                for i in range(3):
                    hand_motors[i].setPosition(hand_motors[i].getMinPosition())

        elif state == 3: # DROPPING
            for i in range(fruit, 5):
                ur_motors[i].setPosition(0.0)
            state = 4 # ROTATE_BACK

        elif state == 4: # ROTATE_BACK
            if position_sensor.getValue() > -0.1:
                state = 0 # WAITING
            
    else:
        counter -= 1

    strP = f'Green Apples: {green_apple:3d}    Red Apples: {red_apple:3d}'
    robot.setLabel(1, strP, 0.3, 0.96, 0.06, 0x00ff00, 0, 'Lucida Console')

    pass

